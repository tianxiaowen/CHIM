## T(ctrl)~Weibull(k,lambda0) density given by dweibull in R
## T(trt)~Weibull(k,lambda1)
## beta: hazard ratio h(trt)/h(ctrl)=(lambda0/lambda1)^k=beta
## rho: full protection Bernoulli(rho)
## N: total sample size
## ratio: n(trt)/n(ctrl)
## Note that in this simulation, censoring==fully protected

#' @import stats
#' @import graphics
#' @import grDevices
#' @import survival
#' @importFrom MASS fitdistr
#' @importFrom beeswarm beeswarm

sim<-function(beta,lambda0,k,rho,N,ratio,endstudy){
  n0<-N/(ratio+1)
  n1<-ratio*N/(ratio+1)
  m<-(1/beta)^(1/k)
  ## x: trt=1, ctrl=0
  x<-c(rep(0,n0),rep(1,n1))
  ## propotional hazard model
  stime<-rweibull(n0+n1,k,m^x*lambda0)
  cstatus<-ifelse(stime>=endstudy,0,1)
  stime<-ifelse(stime>=endstudy, endstudy, stime)
  ## full protection
  x1.index<-rbinom(n1,1,rho)
  fullp.index<-c(rep(0,n0),x1.index)
  cstatus[fullp.index==1]<-0
  stime[fullp.index==1]<-endstudy
  dat<-cbind(time=stime,status=cstatus,x=x)
  dat<-data.frame(dat)
  st<-sort(dat$time,decreasing=FALSE,index.return = TRUE)
  idx<-st$ix
  dat<-dat[idx,]
  return(dat)
}

lachenbruch <- function(dat) {
  x1<-dat[dat$x==0,'status']
  x2<-dat[dat$x==1,'status']
  y1<-dat[dat$x==0&dat$status==1,'time']
  y2<-dat[dat$x==1&dat$status==1,'time']
  n1 <- length(x1)
  p1hat <- sum(x1)/n1
  n2 <- length(x2)
  p2hat <- sum(x2)/n2
  numer <- (p1hat - p2hat)^2
  denom <- p1hat*(1-p1hat)/n1 + p2hat*(1-p2hat)/n2

  keep1 <- !is.na(y1) & y1!=0
  keep2 <- !is.na(y2) & y2!=0

  U <- qnorm(wilcox.test(y1[keep1],y2[keep2])$p.value/2)
  stat <- (numer/denom) + U^2
  if(denom==0){
    stat <- U^2
    df <- 1
  }else{
    stat <- (numer/denom) + U^2
    df <- 2
  }
  pval.lachen<-1-pchisq(stat,df)
  return(pval.lachen)
}

mixlrt<-function(dat){
  x0<-dat[dat$x==0,'time']
  d0<-dat[dat$x==0,'status']
  x11<-dat[dat$x==1&dat$status==1,'time']
  x10<-dat[dat$x==1&dat$status==0,'time']

  ## null model under weibull distribution, lambda0=lambda1, rho=0
  l0<-function(para){
    k<-para[1]
    lambda0<-para[2]
    lambda1<-lambda0
    rho<-0
    log.f0<-log(dweibull(x0,shape=k,scale=lambda0)+1e-10)
    log.s0<-log(1-pweibull(x0,shape=k,scale=lambda0)+1e-10)
    log.f11<-log(dweibull(x11,shape=k,scale=lambda1)+1e-10)
    s10<-1-pweibull(x10,shape=k,scale=lambda1)+1e-10
    loglik<-sum(d0*log.f0)+sum((1-d0)*log.s0)+
      sum(log(1-rho)+log.f11)+sum(log(rho+(1-rho)*s10))
    -loglik
  }

  l0fit<-optim(c(5,8),l0,control=list(maxit=1000),method="L-BFGS-B",lower=c(1e-2,1e-2,1e-2),upper=c(100,100,100))
  l0max<--l0fit$value

  l1<-function(para){
    k<-para[1]
    lambda0<-para[2]
    lambda1<-para[3]
    rho<-para[4]
    log.f0<-log(dweibull(x0,shape=k,scale=lambda0)+1e-10)
    log.s0<-log(1-pweibull(x0,shape=k,scale=lambda0)+1e-10)
    log.f11<-log(dweibull(x11,shape=k,scale=lambda1)+1e-10)
    s10<-1-pweibull(x10,shape=k,scale=lambda1)+1e-10
    loglik<-sum(d0*log.f0)+sum((1-d0)*log.s0)+
      sum(log(1-rho)+log.f11)+sum(log(rho+(1-rho)*s10))
    -loglik
  }

  l1fit<-optim(c(5,6,8,0.5),l1,control=list(maxit=1000),method="L-BFGS-B",lower=c(1e-2,1e-2,1e-2,1e-10),upper=c(100,100,100,1-1e-10))
  l1max<--l1fit$value
  rho.hat<-l1fit$par[4]
  beta.hat<-(l1fit$par[2]/l1fit$par[3])^l1fit$par[1]

  chisq<-2*(l1max-l0max)
  pval.mix<-1-pchisq(chisq,2)
  return(pval.mix)
}

do.one<-function(beta,lambda0,k,rho,N,ratio,endstudy,testname){
  dat<-sim(beta,lambda0,k,rho,N,ratio,endstudy)
  pvals<-rep(NA,5)
  alltests<-c("t-test","wilcox","logrank","lachenbruch","mixlrt")
  name.index<-numeric(length(testname))
  for(i in 1:length(testname)){
    name.index[i]<-which(alltests==testname[i])
  }
  if('t-test'%in%testname){
    pvals[1]<-t.test(time~x,data=dat)$p.value
  }
  if("wilcox"%in%testname){
    pvals[2]<-wilcox.test(time~x,data=dat,exact=FALSE)$p.value
  }
  if("logrank"%in%testname){
    logrank.chisq<-survdiff(formula=Surv(time, status)~x,data = dat)$chisq
    pvals[3]<-pchisq(logrank.chisq,1,lower.tail=FALSE)
  }
  if("lachenbruch"%in%testname){
    pvals[4]<-lachenbruch(dat)
  }
  if("mixlrt"%in%testname){
    pvals[5]<-mixlrt(dat)
  }
  pvals[name.index]
}

#' Power calculation
#' @description Power calculation for t-test, Wilconxon test, log-rank test, Lachenbruch test, and likelihood ratio test for mixture models.
#' @param beta hazard ratio between treatment and control group
#' @param lambda0 scale parameter of Weibull distribution for the control group
#' @param k shape parameter of Weibull distribution
#' @param rho full protection probability for the treatment group, fully protected observations are set to be censored at the end of the study
#' @param N total sample size
#' @param ratio ratio of sample size between treatment and control group
#' @param endstudy time of administrative censoring
#' @param testname name of statistical test chosen from "t-test","wilcox","logrank","lachenbruch","mixlrt".
#' @param alpha statistical significance level
#' @param seed random seed
#' @details The Weibull distribution with shape parameter \eqn{k} and scale parameter \eqn{\lambda} has density given by
#' \eqn{f(x) = \frac{k}{\lambda}(\frac{x}{\lambda})^{k-1}e^{-(x/b)^a}} for \eqn{x>0}.
#' In our simulation studies, time to infection for control group is modeled by \eqn{Weibull(\lambda_0,k)}.
#' Individuals in the treament group have probability \eqn{\rho} being fully protected and their observations are set to be censored.
#' Time to infection for the individuals in the treatment group who don't get full protection from the vaccine will follow \eqn{Weibull(\lambda_1,k)}.
#' Note that the shape parameter \eqn{k} for the Weibull distribution is same for the control and treatment group.
#' Hence the hazard ratio \eqn{\beta} between treatment and control group is constant and has the form of \eqn{(\frac{\lambda_0}{\lambda_1})^k}.
#' @return Power for the statistical tests calculated through 1000 simulations.
#' @export
#'
#' @examples powercal(beta=0.2,lambda0=8,k=5,rho=0.2,
#' N=28,ratio=3,endstudy=28,testname=c('t-test','logrank'),alpha=0.05,seed=1)
powercal<-function(beta,lambda0,k,rho,N,ratio,endstudy,testname,alpha,seed){
  if(beta<=0|beta>1) stop('beta has to be greater than 0 and less than or equal to 1')
  if(lambda0<=0) stop('lambda0 has to be positive')
  if(k<=0) stop('k has to be positive')
  if(rho<0|rho>1) stop('rho has to be greater than or equal to 0 and less than or equal to 1')
  if(ratio<=0) stop('ratio has to be positive')
  if(endstudy<=0) stop('endstudy has to be positive ')
  if(!all(testname%in%c("t-test","wilcox","logrank","lachenbruch","mixlrt"))) stop('testname not specified correctly')
  if(alpha<=0|alpha>=1) stop('rho has to be greater than 0 and less than 1')
  if(N%%(ratio+1)!=0) stop('N is indivisible by (ratio+1)')
  set.seed(seed)
  pvals<-replicate(1000,do.one(beta,lambda0,k,rho,N,ratio,endstudy,testname))
  if(is.null(dim(pvals))){
    result<-mean(pvals<=alpha)
  }else{
    result<-apply(pvals<=alpha,1,mean)
  }
  names(result)<-testname
  print(result)
}

#' Example of simulated dataset
#' @description This function visualize a simulated dataset using a boxplot and a Kaplan-Meier curve.
#' @param beta hazard ratio between treatment and control group
#' @param lambda0 scale parameter of Weibull distribution for the control group
#' @param k shape parameter of Weibull distribution
#' @param rho full protection probability for the treatment group, fully protected observations are set to be censored at the end of the study
#' @param N total sample size
#' @param ratio ratio of sample size between treatment and control group
#' @param endstudy time of administrative sensoring
#' @param seed random seed
#' @details See \code{powercal} for details.
#' @return A boxplot and a Kaplan-Meier curve comparing the simulated treatment and control group
#' @export
#'
#' @examples simexample(beta=0.2,lambda0=8,k=5,rho=0.2,
#' N=28,ratio=3,endstudy=28,seed=1)
simexample<-function(beta,lambda0,k,rho,N,ratio,endstudy,seed){
  if(beta<=0|beta>1) stop('beta has to be greater than 0 and less than or equal to 1')
  if(lambda0<=0) stop('lambda0 has to be positive')
  if(k<=0) stop('k has to be positive')
  if(rho<0|rho>1) stop('rho has to be greater than or equal to 0 and less than or equal to 1')
  if(ratio<=0) stop('ratio has to be positive')
  if(endstudy<=0) stop('endstudy has to be positive ')
  if(N%%(ratio+1)!=0) stop('N is indivisible by (ratio+1)')
  m <- matrix(c(1,2,3,3),nrow = 2,ncol = 2,byrow = TRUE)
  layout(mat = m,heights = c(0.5,0.1))
  par(oma=c(2,0,1,0),mar=c(4,4,3,2))
  set.seed(seed)
  dat<-sim(beta,lambda0,k,rho,N,ratio,endstudy)
  ## boxplot
  col1<-adjustcolor('black',alpha.f=0.5)
  col4<-adjustcolor('blue',alpha.f=0.5)
  boxplot(dat$time~dat$x,col=c(col1,col4),outline = FALSE,ylim=c(0,endstudy),xaxt="n")
  title(bquote(atop(beta~'='~.(beta)~','~rho~'='~.(rho),'N ='~.(N)~','~n[1]/n[0]~'='~.(ratio))),cex=0.8)
  axis(1,at=c(1,2),labels=c("Control","Treatment"))
  beeswarm(dat$time~dat$x,col=c(1,4),pch=16,add=T)

  ## survival
  datsurv<- survfit(Surv(time, status) ~ x,data=dat)
  plot(datsurv,mark.time = T,col=c(1,4),ylab='Survival',xlab='Time',xlim=c(0,endstudy+2))
  title(bquote(atop(beta~'='~.(beta)~','~rho~'='~.(rho),'N ='~.(N)~','~n[1]/n[0]~'='~.(ratio))),cex=0.8)
  par(mai=c(0,0,0,0))
  plot(1, type = "n", axes=FALSE, xlab="", ylab="")
  legend('bottom',legend=c("Treatment","Control"),col=c(4,1),lty=1,cex=0.8,inset=0,pch=16)
}

#' PDF comparison of simulated dataset
#' @description Comparison of probability density function for simulated treatment and control group.
#' @param beta hazard ratio between treatment and control group
#' @param lambda0 scale parameter of Weibull distribution for the control group
#' @param k shape parameter of Weibull distribution
#' @param rho full protection probability for the treatment group, fully protected observations are set to be censored at the end of the study
#' @param endstudy time of administrative censoring
#' @details See \code{powercal} for details.
#' @return A figure comparing the probability density function of simulated treatment and control group.
#' Mean and variance are also shown in the legend.
#' @export
#'
#' @examples pdfsim(beta=0.2,lambda0=8,k=5,rho=0.2,endstudy=28)
pdfsim<-function(beta,lambda0,k,rho,endstudy){
  if(beta<=0|beta>1) stop('beta has to be greater than 0 and less than or equal to 1')
  if(lambda0<=0) stop('lambda0 has to be positive')
  if(k<=0) stop('k has to be positive')
  if(rho<0|rho>1) stop('rho has to be greater than or equal to 0 and less than or equal to 1')
  if(endstudy<=0) stop('endstudy has to be positive ')
  m <- matrix(c(1,2),nrow = 2,ncol = 1,byrow = TRUE)
  layout(mat = m,heights = c(0.5,0.1))
  par(mar=c(4,4,3,2))
  x<-seq(0,endstudy,0.01)
  lambda1<-(1/beta)^(1/k)*lambda0
  plot(x,dweibull(x,k,lambda0),type="l",ylab='Probability density',xlab="Time")
  lines(x,(1-rho)*dweibull(x,k,lambda1)+rho*(x==endstudy),col=4)
  mu0<-lambda0*gamma(1+1/k)
  var0<-lambda0^2*(gamma(1+2/k)-(gamma(1+1/k))^2)
  mu1<-lambda1*gamma(1+1/k)
  var1<-lambda1^2*(gamma(1+2/k)-(gamma(1+1/k))^2)
  mu.mix<-(1-rho)*mu1+rho*endstudy
  var.mix<-(1-rho)^2*var1+rho*(1-rho)*(1-mu1+endstudy)^2
  par(fig=c(0,1,0,1), oma = c(1.5, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
  mu0<-round(mu0,2);mu.mix<-round(mu.mix,2)
  var0<-round(var0,2);var.mix<-round(var.mix,2)
  par(mai=c(0,0,0,0))
  plot(1, type = "n", axes=FALSE, xlab="", ylab="")
  legend('bottom',legend=c(as.expression(bquote("Control:"~mu~'='~.(mu0)~","~sigma^2~'='~.(var0))),
                           as.expression(bquote("Treament:"~mu~'='~.(mu.mix)~","~sigma^2~'='~.(var.mix)))),
         col=c(1,4),lty=1,cex=0.8,inset=0)
}

#' CDF comparison of input data to a Weibull distribution
#' @description Maximum-likelihood fitting of input dataset and comparison of the ecdf and fitted cdf with a user defined Weibull distribution.
#' @param obstime user input data of time to infection
#' @param lambda scale parameter of Weibull distribution
#' @param k shape parameter of Weibull distribution
#' @details See \code{powercal} for details.
#' @return A figure comparing the (empirical) cumulative function of the input dataset, fitted Weibull distribution and a user defined Weibull distribution.
#'
#' An object returned by 'fitdistr' function in the 'MASS' package.
#' @export
#'
#' @examples cdfweibull(rweibull(10,3,6),lambda=8,k=5)
cdfweibull<-function(obstime,lambda,k){
  if(lambda<=0) stop('lambda has to be positive')
  if(k<=0) stop('k has to be positive')
  m <- matrix(c(1,2),nrow = 2,ncol = 1,byrow = TRUE)
  layout(mat = m,heights = c(0.5,0.1))
  par(oma=c(2,0,0,0),mar=c(4,4,3,2))
  lim<-c(qweibull(0.99,k,lambda),max(obstime))
  plot(ecdf(obstime),verticals=T,main="",xlim=c(0,max(lim)+2),ylab='(Empirical) cumulative density',xlab='Time')
  lines(qweibull(seq(0,1,0.01),k,lambda),seq(0,1,0.01),col=4)
  mod<-fitdistr(obstime,'weibull')
  lines(qweibull(seq(0,1,0.01),mod$estimate[1],mod$estimate[2]),seq(0,1,0.01),col=1,lty=2)
  par(mai=c(0,0,0,0))
  plot(1, type = "n", axes=FALSE, xlab="", ylab="")
  legend('bottom',legend=c("Input data ecdf","Input data fitted cdf","Simulated data cdf"),
         col=c(1,1,4),lty=c(1,2,1),cex=0.8,inset=0)
  return(mod)
}




